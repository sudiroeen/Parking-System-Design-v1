from datetime import *
from MxirkaReader import *
from source.included import *
import time
import socket
import threading
import cv2
import os
import pickle
import struct
import shutil
import json
import sys



LED_OFF    = 0x00
LED_GREEN  = 0x02

number = 1
reader = None
listReader = {}
Gate = 'Gate-'
IPserver, PortServer = '192.168.2.5', 8010

def card_inserted_handler(data,IPReader):
	print IPReader
	reader = xirkaReader(IPReader, 1000)
	reader.setServerIP(IPserver, PortServer)
	print 'card has been inserted'

	lFileID = reader.userSendAPDU('00A40000023004')
	rFileID = reader.userSendAPDU('00B0000008')
	nim = rFileID[:-4]
	if nim == '':
		print 'Card unreadable'
		reader.lcdSetText('Card unreadable', '')
		return
	else:
		lFileSaldo = reader.userSendAPDU('00A40000023001') #Untuk baca saldo
		rFileSaldo = reader.userSendAPDU('00B0000008')
		cash = rFileSaldo[:-4]
		Saldo = int(cash,16)
		reader.lcdSetText('Accepted', '')
		timer = reader.rtcGetDatetime()
		waktu = datetime.fromtimestamp(float(timer)).strftime("%I-%M-%S")

		ID = nim.decode("hex")
		print 'ID:', ID
		print 'waktu: ', waktu
		print 'Saldo anda: ',Saldo

		GateNumber = listReader.keys()[listReader.values().index((IPReader, 1000))]
		dataSiapTulis = ID + "_" + GateNumber + "_" + timer + "_"
		print dataSiapTulis
		parkdata = open('TempText/masuk-' + GateNumber.split('-')[1] + '.txt','w+')
		parkdata.write(dataSiapTulis)
		parkdata.close()
		reader.lcdSetText(ID,waktu)
		time.sleep(1)
		reader.lcdSetText('Remove Card','')

def card_removed_handler(IPReader):
	reader = xirkaReader(IPReader,1000)
	reader.setServerIP(IPserver, PortServer)
	reader.lcdSetText('Card', 'has been removed')


def new_reader_notif(IP_Port):
	global number

	IPReader, PortReader = IP_Port.split(':')
	
	reader = xirkaReader(IPReader, int(PortReader))
	print IPReader, PortReader
	reader.setServerIP(IPserver, PortServer)

	print '{}'.format(IPReader, PortReader)
	print '{}'.format((IPReader, int(PortReader)) not in listReader.values())
	if (IPReader, int(PortReader)) not in listReader.values():
		number += 2
		GateNumber = Gate + str(number)
	else:
		GateNumber = listReader.keys()[listReader.values().index((IPReader, 1000))]
	listReader[GateNumber] = IPReader, 1000
	print "New reader detected: ", IPReader
	print listReader

	reader.lcdSetText(GateNumber,'')


if __name__ == "__main__":
	try:
		print "Ready"
		reader = xirkaReader('192.168.2.35', 1000)
		reader.setServerIP(IPserver, PortServer)
		
		GateNumber = Gate + str(number)
		listReader[GateNumber] = reader.reader_ip, reader.reader_port
		print listReader
		reader.eventNewReader(new_reader_notif)

		print "We have: %d gates" %(len(listReader))
		reader.rtcSetDatetime(datetime.utcnow())
		reader.eventUsercardRemoved(card_removed_handler)
		reader.eventUsercardInserted(card_inserted_handler)
		while True:
			pass

	except(KeyboardInterrupt, SystemExit):
		reader.serverShutdown()
		print 'Server shutdown'

#http://192.168.0.107:8080/video