from PyQt5 import QtCore, QtGui, QtWidgets
from lib.xirkaReader import *
import datetime
import source.included
import source.updateGui
import socket
import threading
import cv2
import os
import pickle
import struct
import shutil
import json
import sys


class PintuKeluar:
	def setup(self, Dialog, kamera, gate, fileSimpan, ipServer, portServer, rIPServer, rportServer, rIP, rPort):
		self.reader = xirkaReader(rIP, rPort)
		self.reader.setServerIP(rIPServer, rportServer)

		self.klient = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.klient.connect((ipServer, portServer))
		self.klient.send(gate)

		self.cam = cv2.VideoCapture(kamera)

		self.fileSimpan = fileSimpan

		self.gui = source.updateGui.GUIParkirLuar(Dialog, self.reader, self.fileSimpan)
		
	def kosong(self):
		self.gui.lNID.clear()
		self.gui.lNTimeOut.clear()
		self.gui.lNTimeIn.clear()
		self.gui.lNTimeTotal.clear()
		self.gui.lNBiaya.clear()
		self.gui.lNCheckIn.clear()
		self.gui.lNKembalian.clear()
		self.gui.lNSAwal.clear()
		self.gui.lNSAkhir.clear()
		self.gui.lNImgMasuk.clear()
		self.gui.lNImgKeluar.clear()

	def card_removed_handler(self):
		print 'card has been removed'
		self.reader.lcdSetText('Card has been', 'removed')
	

	def card_inserted_handler(self, data):
		print 'card has been inserted'
		self.reader.lcdSetText('Accepted', '')
		try:
			lFileID = self.reader.userSendAPDU('00A40000023004')
			rFileID = self.reader.userSendAPDU('00B0000008')
			nim = rFileID[:-4]
			ID = nim.decode("hex")

			lFileSaldo = self.reader.userSendAPDU('00A40000023001') #Untuk baca saldo
			rFileSaldo = self.reader.userSendAPDU('00B0000008')
			dSaldoAwal = rFileSaldo[:-4]
			SaldoAwal = int(dSaldoAwal,16)
			print "Saldo anda: ",SaldoAwal
		except:
			self.kosong()
			self.reader.lcdSetText('kartu anda', 'terbalik')
			self.gui.lNMsg.setText('[*] kartu anda terbalik')
			return

		#waktu = datetime.datetime.fromtimestamp(float(timeOut)).strftime("%H:%M:%S")

		timeOut = str(self.reader.rtcGetDatetime())
		detik = str(time.time())
		#ID/Nomor_Tanggal_Jam_jumlahdetik_saldoAwal_
		dataOut = str(ID) + "_" + timeOut.replace(' ', '_') + "_" + detik + '_' +  str(SaldoAwal) + '_'
		self.writeFile(dataOut)

	def writeFile(self, dataOut):
		parkdata = open(self.fileSimpan, "w+")
		parkdata.write(dataOut)
		parkdata.close()
		
	def writeSaldoAkhir(self, SA):
		if SA < 0:
			SA = 0
		else:
			hexsaldo = hex(SA).split('x')[-1]
			for i in range(16):
				if len(hexsaldo)<16:
					hexsaldo=str(0)+hexsaldo
				else:
					hexsaldo=hexsaldo
			hexsaldo = str('00D0000008') + hexsaldo
			lFileSaldo = self.reader.userSendAPDU('00A40000023001')
			wFileSaldo = self.reader.userSendAPDU(hexsaldo)


	def klientRunning(self):
		self.reader.eventUsercardInserted(self.card_inserted_handler)
		self.reader.eventUsercardRemoved(self.card_removed_handler)
		print 'executed'
		while True:
			ret, frame = self.cam.read()

			if not os.path.isfile(self.fileSimpan):
				self.gui.handleButtonRESET
				continue
			else:
				f = open(self.fileSimpan, 'rb')
				#ID/Nomor_Tanggal_Jam_jumlahdetik_saldoAwal_
				dataOut = f.read()
				f.close()

				if len(dataOut.split('_')) == 6:
					print 'fileSimpan: ', self.fileSimpan
					print 'dataOut: ', dataOut

					#ID/Nomor_Tanggal_Jam_jumlahdetik_saldoAwal_Gate-2_Check-Out
					fullnameout = dataOut + uname + '_Check-Out'
					print 'fullnameout: ', fullnameout
					ID = str(dataOut.split('_')[0])
					print 'ID: ', ID
					self.klient.send(ID)
					
					#ID_Tanggal_Jam_jumlahdetik_saldoAwal_Gate-1_Check-In_harga.jpg
					namaIn = self.klient.recv(1024)
					
					if namaIn.split('_')[0] != ID:
						self.kosong()
						print namaIn #ID anda tidak ditemukan
						self.reader.lcdSetText(' '.join(namaIn.split(' ')[0:2]), ' '.join(namaIn.split(' ')[2:4]))
						self.gui.lNMsg.setText('[*] ' +  namaIn)
						os.remove(self.fileSimpan)
						continue
					else:
						print 'namaIn: ', namaIn
						print namaIn.split('.jpg')[0].split('_')
						harga = namaIn.split('.jpg')[0].split('_')[-1]

						#ID_Tanggal_Jam_jumlahdetik_saldoAwal_Gate-1_Check-In.jpg
						namaInCut = namaIn.replace('_'+harga, '')
						print 'namaInCut: ', namaInCut
						#ID_Tanggal_Jam_jumlahdetik_saldoAwal_Gate-1_Check-In.jpg
						namaGambar = namaInCut.replace(namaInCut.split('_')[3] + '_', '')
						print 'bawah: ', namaIn.split('_')[0] == ID

						print 'mau ke imgIn'
						imgIn = source.included.string2img(self.klient, 4096, cv2.IMREAD_COLOR)
						print 'dapet imgIn'
						os.chdir('TempFoto/')
						print 'udah pindah direktori'
						cv2.imwrite(namaGambar, imgIn)
						print 'udah imwrite imgIn'
						#ID/Nomor_Tanggal_Jam_jumlahdetik_saldoAwal_Gate-2_Check-Out
						namaOut = fullnameout.replace(fullnameout.split('_')[3] + '_', '')
						cv2.imwrite(namaOut +'.jpg', frame)
						print "namaOut: ", namaOut
						if (os.path.isfile(namaGambar) & os.path.isfile(namaOut + '.jpg')):
							try:
								#stringIO = ID, GateCheckIn, TImeOut, TimeIn, SaldoAwal
								#stringKomplit = ID, GateCheckIn, TImeOut, TimeIn, (TimeTotal, harga, Biaya), SaldoAwal, (SaldoAkhir)

								## namaIn
								#ID_Tanggal_Jam_jumlahdetik_saldoAwal_Gate-1_Check-In_harga.jpg

								##fullnameout
								##ID/Nomor_Tanggal_Jam_jumlahdetik_saldoAwal_Gate-2_Check-Out


								##stringIO
								#ID, GateCheckIn, TImeOut, TimeIn, SaldoAwal, harga
								print 'sebelum stringIO'
								stringIO = source.included.compoundData(namaIn, fullnameout)
								print 'stringIO: ' + stringIO

								##stringKomplit
								#ID, GateCheckIn, TImeOut, TimeIn, TimeTotal, Biaya, SaldoAwal, SaldoAkhir, harga
								stringKomplit = source.included.complithitung(stringIO)
								print 'stringKomplit: ', stringKomplit

								fullnameout += '_' + stringKomplit.split('_')[5]
								self.klient.send(fullnameout)
								print 'send fullnameout: ', fullnameout

								stringSaldoAkhir = stringKomplit.split('_')[-2]

								if stringSaldoAkhir != 'manual':
									if int(float(stringSaldoAkhir)) < 0:
										self.reader.lcdSetText('Saldo tidak', 'Mencukupi')
									else:
										self.reader.lcdSetText('Saldo Anda: ',stringSaldoAkhir)
										print stringSaldoAkhir
										self.writeSaldoAkhir(int(stringSaldoAkhir))
								self.gui.handleButtonRESET()
								self.gui.tampilanDynamic(stringKomplit) 
								self.gui.tampilanImageDynamic(imgIn, frame)

								print 'move'
								shutil.move(namaGambar, 'IN/')
								shutil.move(namaOut + '.jpg', 'OUT/')
							except:
								os.remove('IN/' + namaGambar)
								shutil.move(namaGambar, 'IN/')
								shutil.move(namaOut + '.jpg', 'OUT/')
								#else:
								#	self.reader.lcdSetText('Anda Sudah', 'keluar')
								#	print 'Anda Sudah keluar'
						os.chdir('../')
						os.remove(self.fileSimpan)
				else:
					continue


if __name__ == '__main__':
	initial = 1546275583.32 #dalam detik (1 January 1970 sampai 1 January 2019)
	uname = 'Gate-2'
	ipCamera = 0#"http://192.168.1.5:8080/video"
	ipServer, portServer = '127.0.89.67', 1234 #'192.168.0.114', 1234 #'127.0.89.67', 1234
	rIP, rPort = '192.168.2.35', 1000#'10.42.0.67', 1000
	rIPServer, rportServer = '192.168.2.5', 8010
	fileSimpan = 'TempText/keluar.txt'


	app = QtWidgets.QApplication(sys.argv)
	Dialog = QtWidgets.QDialog()
	

	keluar = PintuKeluar()
	#def setup(self, gui, kamera, gate, fileSimpan, ipServer, portServer, rIPServer, rportServer, rIP, rPort):
	keluar.setup(Dialog, ipCamera, uname, fileSimpan, ipServer, portServer, rIPServer, rportServer, rIP, rPort)

	#keluar.gui(Dialog)
	keluar.reader.rtcSetDatetime(datetime.datetime.utcnow())

	threading.Thread(target= keluar.klientRunning).start()
	Dialog.show()
	app.exec_()
