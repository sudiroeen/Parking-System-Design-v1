from lib.xirkaReader import *
from lib.included import *
import socket
import threading
import cv2
import os
import pickle
import struct
import shutil
import json
import sys

class PintuMasuk:
	def setup(self, kamera, gate, fileSimpan, ipServer, portServer, rIPServer, rportServer, rIP, rPort):
		self.reader = xirkaReader(rIP, rPort)
		self.reader.setServerIP(rIPServer, rportServer)

		self.klient = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.klient.connect((ipServer, portServer))
		self.klient.send(gate)

		self.cam = cv2.VideoCapture(kamera)

		self.fileSimpan = fileSimpan

		self.gate = gate
		self.nGate = str(int(self.gate.split('-')[-1]))

		self.counter = 0
		setOfFiles = os.listdir('TempFoto/')
		print [j.split('_')[3] for j in setOfFiles if j.split('_')[0].split('A')[0] is self.nGate]
		try:
			if self.gate not in [j.split('_')[3] for j in setOfFiles if j.split('_')[0].split('A')[0] is self.nGate]:
				self.counter = 0
			if len(setOfFiles) != 0:
				self.counter = max([int(i.split('_')[0].split((self.nGate + 'A'))[1]) for i in setOfFiles if len(i.split('_')[0].split((self.nGate + 'A'))) == 2 ])
		except:
			self.counter = 0		


	def klientRunning(self):
		self.reader.eventUsercardRemoved(self.card_removed_handler)
		self.reader.eventUsercardInserted(self.card_inserted_handler)
		self.reader.eventKeypadNewInput(self.keypad_input_handler)

		while True:
			ret, frame = self.cam.read()
			if not os.path.isfile(self.fileSimpan):
				continue
			else:
				encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 95]
				#ID_Tanggal_Jam_jumlahdetik_saldoAwal
				msg = open(self.fileSimpan, 'rb').read()
				#ID_Tanggal_Jam_jumlahdetik_saldoAwal_Gate-1_Check-In
				msg = msg + uname + '_Check-In'

				#ID_Tanggal_Jam_jumlahdetik_saldoAwal_Gate-1_Check-In
				self.klient.send(msg)

				#strfTime = str(time.strftime("%Y-%m-%d_%H:%M:%S", time.localtime()))
				#msg = msg.replace(msg.split('_')[1], strfTime)

				#ID_Tanggal_Jam_saldoAwal_Gate-1_Check-In
				namaGambar = msg.replace(msg.split('_')[3] + '_', '')
				cv2.imwrite('TempFoto/' + namaGambar +'.jpg', frame)

				msgImg = img2string(frame, encode_param)
				self.klient.sendall(msgImg)
				os.remove(self.fileSimpan)

	def card_removed_handler(self):
		self.reader.lcdSetText('Card has been', 'removed')
		print 'card has been removed'

	def card_inserted_handler(self, data):
		print 'card has been inserted'
		try:
			lFileID = self.reader.userSendAPDU('00A40000023004')
			rFileID = self.reader.userSendAPDU('00B0000008')
			nim = rFileID[:-4]
			ID = nim.decode("hex")
			print 'ID:', ID

			#'00D0000008' + 8 bit saldo

			lFileSaldo = self.reader.userSendAPDU('00A40000023001') #Untuk baca saldo
			rFileSaldo = self.reader.userSendAPDU('00B0000008')
			dSaldoAwal = rFileSaldo[:-4]
			SaldoAwal = int(dSaldoAwal,16)
			
			if (ID == '') or (dSaldoAwal == ''):
				self.reader.lcdSetText("Card not readable")
				return
			self.reader.lcdSetText('Accepted', '')
			timeIn = str(self.reader.rtcGetDatetime())
			self.reader.lcdSetText(ID, timeIn)
			time.sleep(1)
			self.reader.lcdSetText('Remove Card','')
			#waktu = datetime.fromtimestamp(float(timeIn)).strftime("%H-%M-%S")

			#data = str(data)
			detik = str(time.time())

			#ID_Tanggal_Jam_jumlahdetik_saldoAwal
			dataIn = ID + "_" + timeIn.replace(' ', '_') + '_' + detik + '_' +  str(SaldoAwal) + '_'

			parkdata = open(self.fileSimpan,'w+')
			parkdata.write(dataIn)
			parkdata.close()
		except:
			print '[*] Kartu Anda terbalik'
			self.reader.lcdSetText('Kartu Anda', 'terbalik')


	#def nilai_statik(**variable):
	#	def dekorasi(fungsi):
	#		for i in variable:
	#			setattr(fungsi, i, variable[i])
	#		return fungsi
	#	return dekorasi

	#@nilai_statik(counter = 0)
	def keypad_input_handler(self, data):
		self.counter += 1
		print 'Keypad input:', self.counter #keypad_input_handler.counter
		self.reader.lcdSetText('Accepted', '')

		timeIn = str(self.reader.rtcGetDatetime())
		#waktu = datetime.fromtimestamp(float(timeIn)).strftime("%H-%M-%S")
		self.reader.lcdSetText(str(self.counter),timeIn)
		detik = str(time.time())

		#Nomor_Tanggal_Jam_jumlahdetik_saldoAwal(manual)_
		dataIn = str(self.nGate + 'A' + str(self.counter)) + "_" + timeIn.replace(' ', '_') + '_' + detik + '_manual_'

		parkdata = open(self.fileSimpan,'w+')
		parkdata.write(dataIn)
		parkdata.close()

	#keypad_input_handler.counter = 0

initial = 1546275583.32 #dalam detik (1 January 1970 sampai 1 January 2019)
uname = 'Gate-1'
ipCamera =  0#'http://192.168.0.107:8080/video' #0
ipServer, portServer = '127.0.89.67', 1234 #'192.168.0.114', 1234 #'127.0.89.67', 1234
rIP, rPort = '192.168.2.35', 1000 #'10.42.0.67', 1000
rIPServer, rportServer = '192.168.2.5', 8010
fileSimpan = 'TempText/masuk.txt'


#def setup(self, kamera, gate, fileSimpan, ipServer, portServer, rIPServer, rportServer, rIP, rPort):
masuk = PintuMasuk()
masuk.setup(ipCamera, uname, fileSimpan, ipServer, portServer, rIPServer, rportServer, rIP, rPort)
masuk.klientRunning()