from datetime import *
from MxirkaReader import *
from source.included import *
import time
import socket
import threading
import cv2
import os
import pickle
import struct
import shutil
import json
import sys



LED_OFF    = 0x00
LED_GREEN  = 0x02

number = 1
reader = None
listReader = {}
Gate = 'Gate-'
Masuk = 'TempText/masuk-'
IPserver, PortServer = '192.168.2.5', 8010

LOAD_FILE_ID = '00A40000023004'
LOAD_FILE_SALDO = '00A40000023001'

READ_FILE_ID = '00B0000008'
READ_FILE_SALDO = '00B0000008'

class MultiMasuk:
	def __init__(self, jsonCamera, number, IPServer, PortServer, rIP, rPort, rIPServer, rPortServer):
		self.number = number

		self.IPserver = IPserver
		self.PortServer = PortServer

		self.reader = xirkaReader('192.168.2.35', 1000)
		self.reader.setServerIP(IPserver, PortServer)

		self.jsonCamera = jsonCamera

		self.counter = 0
		setOfFiles = os.listdir('TempFoto/')
		print [j.split('_')[3] for j in setOfFiles if j.split('_')[0].split('A')[0] is self.nGate]
		try:
			if self.gate not in [j.split('_')[3] for j in setOfFiles if j.split('_')[0].split('A')[0] is self.nGate]:
				self.counter = 0
			if len(setOfFiles) != 0:
				self.counter = max([int(i.split('_')[0].split(self.nGate + 'A')[1]) for i in setOfFiles if len(i.split('_')[0].split(self.nGate + 'A')) == 2 ])
		except:
			self.counter = 0	
		
	def MultiRunning(self):
		self.GateNumber = Gate + str(self.number)

		self.listReader[self.GateNumber] = self.reader.reader_ip, self.reader.reader_port
		self.reader.eventNewReader(self.new_reader_notif)
		
		self.reader.eventUsercardRemoved(self.card_removed_handler)
		self.reader.eventUsercardInserted(self.card_inserted_handler)
		while True:
			pass

	def new_reader_notif(IP_Port):
		IPReader, PortReader = IP_Port.split(':')
		
		self.reader = xirkaReader(IPReader, int(PortReader))
		print IPReader, PortReader
		self.reader.setServerIP(self.IPserver, self.PortServer)

		print '{}'.format(IPReader, PortReader)
		print '{}'.format((IPReader, int(PortReader)) not in listReader.values())
		if (IPReader, int(PortReader)) not in listReader.values():
			self.number += 2
			self.GateNumber = Gate + str(self.number)
		else:
			self.GateNumber = listReader.keys()[listReader.values().index((IPReader, 1000))]
		listReader[self.GateNumber] = IPReader, 1000
		print "New reader detected: ", IPReader
		print listReader

		self.reader.lcdSetText(self.GateNumber,'')


	def card_inserted_handler(data,IPReader):
		lc = open(self.jsonCamera)
		self.camera = json.load(lc)

		self.cam = cv2.VideoCapture(self.camera[self.GateNumber])


		print IPReader
		self.reader = xirkaReader(IPReader, 1000)
		self.reader.setServerIP(self.IPserver, self.PortServer)
		print 'card has been inserted'

		lFileID = reader.userSendAPDU(LOAD_FILE_ID)
		rFileID = reader.userSendAPDU(READ_FILE_ID)
		nim = rFileID[:-4]
		if nim == '':
			print 'Card unreadable'
			reader.lcdSetText('Card unreadable', '')
			return
		else:
			lFileSaldo = reader.userSendAPDU(LOAD_FILE_SALDO) #Untuk baca saldo
			rFileSaldo = reader.userSendAPDU(READ_FILE_SALDO)
			cash = rFileSaldo[:-4]
			Saldo = int(cash,16)
			reader.lcdSetText('Accepted', '')
			timer = reader.rtcGetDatetime()
			waktu = datetime.fromtimestamp(float(timer)).strftime("%I-%M-%S")

			ID = nim.decode("hex")
			print 'ID:', ID
			print 'waktu: ', waktu
			print 'Saldo anda: ',Saldo

			self.GateNumber = listReader.keys()[listReader.values().index((IPReader, 1000))]
			dataSiapTulis = ID + "_" + self.GateNumber + "_" + timer + "_"
			print dataSiapTulis

			self.fileSimpan = Masuk + self.GateNumber.split('-')[1] + '.txt'
			parkdata = open(,'w+')
			parkdata.write(dataSiapTulis)
			parkdata.close()

			self.reader.lcdSetText(ID,waktu)
			time.sleep(1)
			self.reader.lcdSetText('Remove Card','')

			self.eksekusi()

	def eksekusi(self):
		while True:
			ret, frame = self.cam.read()
			if not os.path.isfile(self.fileSimpan):
				continue
			else:
				encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 95]
				#ID_Tanggal_Jam_jumlahdetik_saldoAwal
				msg = open(self.fileSimpan, 'rb').read()
				#ID_Tanggal_Jam_jumlahdetik_saldoAwal_Gate-1_Check-In
				msg = msg + uname + '_Check-In'

				#ID_Tanggal_Jam_jumlahdetik_saldoAwal_Gate-1_Check-In
				self.klient.send(msg)

				#strfTime = str(time.strftime("%Y-%m-%d_%H:%M:%S", time.localtime()))
				#msg = msg.replace(msg.split('_')[1], strfTime)

				#ID_Tanggal_Jam_saldoAwal_Gate-1_Check-In
				namaGambar = msg.replace(msg.split('_')[3] + '_', '')
				cv2.imwrite('TempFoto/' + namaGambar +'.jpg', frame)

				msgImg = img2string(frame, encode_param)
				self.klient.sendall(msgImg)
				os.remove(self.fileSimpan)

	def card_removed_handler(IPReader):
		self.reader = xirkaReader(IPReader,1000)
		self.reader.setServerIP(self.IPserver, self.PortServer)
		self.reader.lcdSetText('Card', 'has been removed')

	def keypad_input_handler(self, data, IPReader):
		self.reader = xirkaReader(IPReader,1000)
		self.reader.setServerIP(self.IPserver, self.PortServer)

		self.counter += 1
		print 'Keypad input:', self.counter #keypad_input_handler.counter
		self.reader.lcdSetText('Accepted', '')

		timeIn = str(self.reader.rtcGetDatetime())
		#waktu = datetime.fromtimestamp(float(timeIn)).strftime("%H-%M-%S")
		self.reader.lcdSetText(str(self.counter),timeIn)
		detik = str(time.time())

		#Nomor_Tanggal_Jam_jumlahdetik_saldoAwal(manual)_
		dataIn = str(self.nGate + 'A' + str(self.counter)) + "_" + timeIn.replace(' ', '_') + '_' + detik + '_manual_'

		self.fileSimpan = Masuk + self.GateNumber.split('-')[1] + '.txt'
		
		parkdata = open(self.fileSimpan,'w+')
		parkdata.write(dataIn)
		parkdata.close()

