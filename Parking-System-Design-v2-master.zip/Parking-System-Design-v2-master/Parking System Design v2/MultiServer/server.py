import socket
import threading
import cv2
import os
import pickle
import struct
import shutil
import json
from source.included import *

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serverRunning = True
ip = '127.0.89.67' 
port = 1234

clients = {}
qomus = {}

try:
	if os.path.isfile('Text/Permanent/kamus.txt'):
		print 'eksekusi'
		with open('Text/Permanent/kamus.txt', 'rb') as jsonBaca:
			qomus = json.load(jsonBaca)
	else:
		print 'else'
		qomus = {}
except:
	print 'except'
	qomus = {}
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind((ip, port))
server.listen(10)
print('Server Ready...')
print('Ip Address of the Server::%s'%ip)

def handleMasuk(client, uname):
	print 'Masuk'
	InConnect = True


	while InConnect:
		try:
			#ID/Nomor_Tanggal_Jam_jumlahdetik_saldoAwal_Gate-1_Check-In
			msg = client.recv(2048)

			#strfTime = str(time.strftime("%Y-%m-%d_%H:%M:%S", time.localtime()))
			#dIn = msg.replace(msg.split('_')[1], strfTime)
			try:
				h = open('Text/Permanent/harga/harga.txt')
				harga = str(h.read()).split('\n')[0]
				h.close()
				if harga == '':
					continue
			except:
				pass
			#"ID": "Tanggal_Jam_jumlahdetik_saldoAwal_Gate-1_Check-In_harga"
			ID, ISI = string2dict(msg + '_' + harga)

			kamus = isiKamus(qomus, ID, ISI)

			#"ID": "Tanggal_Jam_jumlahdetik_saldoAwal_Gate-1_Check-In_harga"
			with open('Text/Permanent/kamus.txt', 'w') as apkm:
				json.dump(kamus, apkm)

			#ID/Nomor_Tanggal_Jam_saldoAwal_Gate-1_Check-In
			namaGambar = msg.replace(msg.split('_')[3] + '_', '')

			with open('Text/Permanent/dIn.txt', 'a+') as aIn:
				aIn.write(namaGambar + '\n')
			with open('Text/dTempIn-'+ uname.split('-')[-1] + '.txt', 'w') as wkm:
				wkm.write(namaGambar)

			img = string2img(client, 4096, cv2.IMREAD_COLOR)

			cv2.imwrite('Foto/'+ namaGambar + '.jpg', img)
		except:
			clients.pop(uname)
			print (uname + 'has been logged out')
			continue

def handleKeluar(client, uname):
	OutConnect = True
	encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 95]
	while OutConnect:
		try:
			ID = client.recv(1024)
			nama = ''
			try:
				#"ID": "_Tanggal_Jam_jumlahdetik_saldoAwal_Gate-1_Check-In_harga"
				with open('Text/Permanent/kamus.txt', 'rb') as rkm:
					bcKamus = json.load(rkm)
					isiID = str(bcKamus[ID][len(bcKamus[ID])-1][u'' + str(len(bcKamus[ID]))])
					nama = ID + isiID + '.jpg'
				client.send(nama)
				try:
					jumlahdetik = '_' + nama.split('_')[3]
					print "jumlahdetik: ", jumlahdetik
					harga = '_' + nama.split('.jpg')[0].split('_')[-1]
					print 'harga: ', harga
					namaGambar = nama.replace(jumlahdetik, '').replace(harga, '')
					print "namaGambar: ", namaGambar
					img = cv2.imread('Foto/'+namaGambar)
					strImg = img2string(img, encode_param)
				except:
					print 'Image no longer exist'
					continue
				client.sendall(strImg)
				dOut = client.recv(4096)

				#strfTime = str(time.strftime("%Y-%m-%d_%H:%M:%S", time.localtime()))

				dOutFix = dOut.replace(dOut.split('_')[3] + '_', '')
				with open('Text/Permanent/dOut.txt', 'a+') as aOut:
					aOut.write(dOutFix + '\n')
				with open('Text/dTempIn-' + uname.split('-')[-1] +'.txt', 'w') as TaOut:
					TaOut.write(dOutFix)
			except:
				client.send('ID anda tidak ditemukan')
				continue
		except:
			clients.pop(uname)
			print (uname + 'has been logged out')
			continue

while serverRunning:
	client, address = server.accept()
	uname = client.recv(1024)
	print('%s connected to the server'%str(uname))
	
	if(client not in clients):
		clients[uname] = client
		noGate = int(uname.split('-')[1])
		if noGate % 2 != 0:
			threading.Thread(target = handleMasuk, args = (client, uname, )).start()
		elif noGate % 2 ==0:
			threading.Thread(target = handleKeluar, args = (client, uname, )).start()
